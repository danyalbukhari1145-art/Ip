// ============================================================
// routes/checkRoutes.js
// Defines the /api/check endpoint. Keeps route wiring separate
// from business logic (controllers) and cross-cutting concerns
// (middleware).
// ============================================================

const express = require('express');
const router = express.Router();

const validateAgent = require('../middleware/validateAgent');
const extractIp = require('../middleware/extractIp');
const { checkAgent } = require('../controllers/checkController');

// GET /api/check?agent_id=ABC123
router.get('/check', validateAgent, extractIp, checkAgent);

module.exports = router;
