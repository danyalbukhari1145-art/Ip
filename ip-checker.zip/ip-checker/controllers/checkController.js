// ============================================================
// controllers/checkController.js
// Orchestrates the "check" flow:
//   1. Increment the agent's open_count
//   2. Detect the visitor's IP (done by extractIp middleware)
//   3. Record the visit and determine Unique vs Duplicate
//   4. Respond with JSON the frontend renders
// ============================================================

const agentModel = require('../models/agentModel');
const visitorModel = require('../models/visitorModel');

async function checkAgent(req, res) {
  const agentId = req.agentId; // set by validateAgent middleware
  const ip = req.visitorIp; // set by extractIp middleware

  try {
    // Step 1: ensure the agent exists and bump its open_count.
    // (This runs on EVERY page load, per the spec.)
    const agent = await agentModel.getOrCreateAndIncrement(agentId);

    // Step 2 & 3: record this IP for the agent (atomic
    // insert-if-not-exists) and get back Unique/Duplicate.
    const ipStatus = await visitorModel.recordVisit(agentId, ip);

    return res.status(200).json({
      success: true,
      data: {
        agent_id: agent.agent_id,
        open_count: agent.open_count,
        ip_address: ip,
        ip_status: ipStatus, // "Unique" | "Duplicate"
      },
    });
  } catch (err) {
    console.error('[checkAgent] Error:', err);
    return res.status(500).json({
      success: false,
      error: 'Internal server error while processing the request.',
    });
  }
}

module.exports = { checkAgent };
