// ============================================================
// models/visitorModel.js
// All database access for the `visitors` table lives here.
// Uses parameterized queries exclusively (SQL injection safe).
// ============================================================

const { pool } = require('../config/db');

/**
 * Record a visit for (agentId, ipAddress) if it doesn't already
 * exist, and report whether this IP is "Unique" (first time
 * seen for this agent) or "Duplicate" (already recorded).
 *
 * This uses `INSERT IGNORE` against the UNIQUE KEY (agent_id,
 * ip_address). That makes the check-then-insert atomic at the
 * database level, so two simultaneous requests from the same
 * IP can never both be recorded as "Unique" (no race condition
 * from a separate SELECT-then-INSERT pattern).
 *
 * @param {string} agentId
 * @param {string} ipAddress
 * @returns {Promise<'Unique'|'Duplicate'>}
 */
async function recordVisit(agentId, ipAddress) {
  const [result] = await pool.execute(
    `INSERT IGNORE INTO visitors (agent_id, ip_address)
     VALUES (?, ?)`,
    [agentId, ipAddress]
  );

  // affectedRows === 1  -> a new row was inserted -> first time we've seen this IP
  // affectedRows === 0  -> INSERT IGNORE skipped a duplicate key -> already existed
  return result.affectedRows === 1 ? 'Unique' : 'Duplicate';
}

/**
 * List all recorded IPs for a given agent (useful for an
 * admin/debug view; not required by the core spec but handy).
 * @param {string} agentId
 */
async function listByAgentId(agentId) {
  const [rows] = await pool.execute(
    'SELECT ip_address, first_visit FROM visitors WHERE agent_id = ? ORDER BY first_visit ASC',
    [agentId]
  );
  return rows;
}

module.exports = {
  recordVisit,
  listByAgentId,
};
