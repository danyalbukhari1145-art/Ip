// ============================================================
// models/agentModel.js
// All database access for the `agents` table lives here.
// Every query uses parameterized ("?") placeholders — this is
// what protects the app from SQL injection. Never string-
// concatenate user input into SQL.
// ============================================================

const { pool } = require('../config/db');

/**
 * Fetch a single agent row by agent_id.
 * @param {string} agentId
 * @returns {Promise<object|null>}
 */
async function findByAgentId(agentId) {
  const [rows] = await pool.execute(
    'SELECT id, agent_id, open_count, created_at FROM agents WHERE agent_id = ? LIMIT 1',
    [agentId]
  );
  return rows.length ? rows[0] : null;
}

/**
 * Create a new agent row with open_count starting at 0.
 * Uses INSERT ... ON DUPLICATE KEY UPDATE as a safety net in
 * case of a race between two simultaneous first-time requests
 * for the same agent_id (agent_id has a UNIQUE constraint).
 * @param {string} agentId
 */
async function createAgent(agentId) {
  await pool.execute(
    `INSERT INTO agents (agent_id, open_count)
     VALUES (?, 0)
     ON DUPLICATE KEY UPDATE agent_id = agent_id`,
    [agentId]
  );
}

/**
 * Atomically increment the open_count for an agent and return
 * the updated row. Doing the increment in SQL (rather than
 * read-then-write in JS) avoids lost updates under concurrency.
 * @param {string} agentId
 * @returns {Promise<object>} updated agent row
 */
async function incrementOpenCount(agentId) {
  await pool.execute(
    'UPDATE agents SET open_count = open_count + 1 WHERE agent_id = ?',
    [agentId]
  );
  return findByAgentId(agentId);
}

/**
 * Ensure an agent row exists, then atomically increment it.
 * This is the main entry point used by the controller.
 * @param {string} agentId
 * @returns {Promise<object>} updated agent row
 */
async function getOrCreateAndIncrement(agentId) {
  let agent = await findByAgentId(agentId);
  if (!agent) {
    await createAgent(agentId);
  }
  agent = await incrementOpenCount(agentId);
  return agent;
}

module.exports = {
  findByAgentId,
  createAgent,
  incrementOpenCount,
  getOrCreateAndIncrement,
};
