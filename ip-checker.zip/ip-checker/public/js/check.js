// ============================================================
// public/js/check.js
// Runs in the browser. Reads `agent_id` from the URL query
// string, calls the backend API, and renders the result.
// ============================================================

(function () {
  const loadingEl = document.getElementById('loading');
  const resultEl = document.getElementById('result');
  const errorEl = document.getElementById('error');
  const errorMessageEl = document.getElementById('errorMessage');

  function show(el) {
    el.classList.remove('hidden');
  }
  function hide(el) {
    el.classList.add('hidden');
  }

  function showError(message) {
    hide(loadingEl);
    hide(resultEl);
    errorMessageEl.textContent = message;
    show(errorEl);
  }

  function showResult(data) {
    hide(loadingEl);
    hide(errorEl);

    document.getElementById('agentId').textContent = data.agent_id;
    document.getElementById('openCount').textContent = data.open_count;
    document.getElementById('ipAddress').textContent = data.ip_address;

    const statusEl = document.getElementById('ipStatus');
    statusEl.textContent = data.ip_status;
    statusEl.classList.remove('unique', 'duplicate');
    statusEl.classList.add(data.ip_status === 'Unique' ? 'unique' : 'duplicate');

    show(resultEl);
  }

  async function run() {
    const params = new URLSearchParams(window.location.search);
    const agentId = params.get('agent_id');

    if (!agentId) {
      showError('Missing required URL parameter: agent_id');
      return;
    }

    try {
      const response = await fetch(
        `/api/check?agent_id=${encodeURIComponent(agentId)}`,
        { method: 'GET', headers: { Accept: 'application/json' } }
      );

      const payload = await response.json();

      if (!response.ok || !payload.success) {
        showError(payload.error || 'Something went wrong. Please try again.');
        return;
      }

      showResult(payload.data);
    } catch (err) {
      showError('Unable to reach the server. Please check your connection.');
    }
  }

  run();
})();
