// ============================================================
// middleware/validateAgent.js
// Validates the `agent_id` query parameter before any
// controller/database logic runs.
// ============================================================

// Only allow letters, numbers, underscore and hyphen, 3-64
// chars long. Adjust to match whatever format you actually
// generate your agent IDs with.
const AGENT_ID_PATTERN = /^[A-Za-z0-9_-]{3,64}$/;

function validateAgent(req, res, next) {
  const { agent_id: agentId } = req.query;

  // 1. Missing entirely
  if (!agentId || typeof agentId !== 'string' || agentId.trim() === '') {
    return res.status(400).json({
      success: false,
      error: 'Missing required query parameter: agent_id',
    });
  }

  // 2. Format check (also blocks SQL-injection-style payloads,
  //    though the parameterized queries in the models are the
  //    real defense — this is defense-in-depth).
  if (!AGENT_ID_PATTERN.test(agentId)) {
    return res.status(400).json({
      success: false,
      error:
        'Invalid agent_id format. Allowed characters: letters, numbers, "_" and "-", length 3-64.',
    });
  }

  // Attach the sanitized value for downstream use.
  req.agentId = agentId;
  next();
}

module.exports = validateAgent;
