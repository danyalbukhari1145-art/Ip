// ============================================================
// middleware/extractIp.js
// Determines the visitor's public IP address.
//
// IMPORTANT: if this app runs behind a reverse proxy or load
// balancer (Nginx, Heroku, AWS ELB, Cloudflare, etc.) you MUST
// set `app.set('trust proxy', true)` in server.js (already
// done) so that `req.ip` / `req.ips` correctly reflect the
// X-Forwarded-For header instead of the proxy's own IP.
// ============================================================

function extractIp(req, res, next) {
  // req.ip already respects the 'trust proxy' setting and the
  // X-Forwarded-For chain. We fall back to the raw socket
  // address if for some reason req.ip is unavailable.
  let ip = req.ip || req.connection.remoteAddress || '';

  // Normalize IPv4-mapped IPv6 addresses like "::ffff:203.0.113.5"
  // down to plain "203.0.113.5" for readability/consistency.
  if (ip.startsWith('::ffff:')) {
    ip = ip.substring(7);
  }

  req.visitorIp = ip;
  next();
}

module.exports = extractIp;
