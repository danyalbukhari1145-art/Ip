// ============================================================
// config/db.js
// Creates a single, reusable MySQL connection pool for the
// whole application. Using a pool (instead of one connection)
// lets Express handle many concurrent requests efficiently.
// ============================================================

require('dotenv').config();
const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host: process.env.DB_HOST || '127.0.0.1',
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: Number(process.env.DB_CONNECTION_LIMIT) || 10,
  queueLimit: 0,
  // Return JS Date objects instead of strings for TIMESTAMP columns
  dateStrings: false,
});

// Simple helper to verify the DB is reachable at startup.
async function testConnection() {
  const conn = await pool.getConnection();
  try {
    await conn.ping();
    console.log('[DB] MySQL connection pool established successfully.');
  } finally {
    conn.release();
  }
}

module.exports = { pool, testConnection };
